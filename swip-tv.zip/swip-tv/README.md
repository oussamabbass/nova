# Swip TV – Stories

**© 2026 Swip TV – All Rights Reserved**  
**Admin :** oussamabbass500@gmail.com

## Nouvelle direction

Application de **statuts / stories** (style Snapchat / WhatsApp Status).

Plus de chat vidéo aléatoire Omegle → **stories éphémères 24 h**.

### Fonctionnalités

- Stories **photo**, **vidéo** et **texte**
- Anneaux de statuts (vus / non vus)
- Caméra frontale / arrière
- Viewer plein écran avec barre de progression
- Expiration automatique après **24 heures**
- Pseudo local + couleur d’avatar
- Temps réel léger (Socket.IO : nouvelle story)
- Pages légales `/privacy` et `/terms`

### GitHub

```bash
git clone https://github.com/TON_USERNAME/swip-tv.git
cd swip-tv
pip install -r requirements.txt
python app.py
```

### Installation

```bash
cd swip-tv
pip install -r requirements.txt
python app.py
```

→ http://localhost:5000

### API

| Méthode | Route | Description |
|---------|-------|-------------|
| GET | `/api/stories?user_id=` | Liste des anneaux / stories |
| POST | `/api/story` | Publier une story |
| POST | `/api/story/<id>/view` | Marquer comme vue |
| GET | `/health` | Status serveur |

### Structure

```
swip-tv/
├── app.py
├── requirements.txt
├── static/
│   ├── stories/          # médias uploadés
│   ├── sw.js
│   └── manifest.json
└── templates/
    ├── index.html
    ├── privacy.html
    └── terms.html
```

---
© 2026 Swip TV – All Rights Reserved
