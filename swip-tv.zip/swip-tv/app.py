# © 2026 Swip TV – All Rights Reserved
# Admin: oussamabbass500@gmail.com
# Direction: Stories / Status (style Snap)

from flask import Flask, render_template, request, jsonify, send_from_directory
from flask_socketio import SocketIO, emit
import uuid
import logging
import os
import base64
import time
from datetime import datetime, timedelta
from threading import Lock

app = Flask(__name__)
app.config['SECRET_KEY'] = 'swiptv_secret_key_change_me_in_production'
app.config['MAX_CONTENT_LENGTH'] = 12 * 1024 * 1024  # 12 MB

socketio = SocketIO(
    app,
    cors_allowed_origins="*",
    async_mode='threading',
    logger=False,
    engineio_logger=False,
    ping_timeout=60,
    ping_interval=25
)

logging.basicConfig(level=logging.INFO)
log = logging.getLogger('swiptv')

ADMIN_EMAILS = {"oussamabbass500@gmail.com"}
STORY_TTL_HOURS = 24
STORIES_DIR = os.path.join(os.path.dirname(__file__), 'static', 'stories')
os.makedirs(STORIES_DIR, exist_ok=True)

# ============================================
# DATA
# ============================================
# users: sid -> profile
users = {}
# stories: list of story dicts
stories = []
stories_lock = Lock()

# story = {
#   id, user_id, username, avatar_color,
#   type: 'image'|'video'|'text',
#   media_url or text, caption,
#   created_at, expires_at,
#   views: set of user_ids
# }


def now_ts():
    return time.time()


def cleanup_expired_stories():
    """Supprime les stories > 24h"""
    cutoff = now_ts()
    with stories_lock:
        keep = []
        for s in stories:
            if s['expires_at'] > cutoff:
                keep.append(s)
            else:
                # delete file if any
                if s.get('media_path'):
                    try:
                        os.remove(s['media_path'])
                    except OSError:
                        pass
        stories[:] = keep


def public_story(s, viewer_id=None):
    return {
        'id': s['id'],
        'user_id': s['user_id'],
        'username': s['username'],
        'avatar_color': s.get('avatar_color', '#B8860B'),
        'type': s['type'],
        'media_url': s.get('media_url'),
        'text': s.get('text'),
        'caption': s.get('caption', ''),
        'created_at': s['created_at'],
        'expires_at': s['expires_at'],
        'views_count': len(s.get('views', set())),
        'seen': viewer_id in s.get('views', set()) if viewer_id else False
    }


def group_stories_by_user(viewer_id=None):
    cleanup_expired_stories()
    grouped = {}
    with stories_lock:
        for s in sorted(stories, key=lambda x: x['created_at']):
            uid = s['user_id']
            if uid not in grouped:
                grouped[uid] = {
                    'user_id': uid,
                    'username': s['username'],
                    'avatar_color': s.get('avatar_color', '#B8860B'),
                    'has_unseen': False,
                    'stories': []
                }
            item = public_story(s, viewer_id)
            grouped[uid]['stories'].append(item)
            if not item['seen']:
                grouped[uid]['has_unseen'] = True
    # My story first, then unseen, then seen
    result = list(grouped.values())
    def sort_key(g):
        is_me = 0 if viewer_id and g['user_id'] == viewer_id else 1
        unseen = 0 if g['has_unseen'] else 1
        return (is_me, unseen, -max(st['created_at'] for st in g['stories']))
    result.sort(key=sort_key)
    return result


# ============================================
# ROUTES
# ============================================

@app.route('/')
def index():
    return render_template('index.html')


@app.route('/privacy')
def privacy():
    return render_template('privacy.html')


@app.route('/terms')
def terms():
    return render_template('terms.html')


@app.route('/health')
def health():
    cleanup_expired_stories()
    return {
        'status': 'ok',
        'online': len(users),
        'stories': len(stories),
        'mode': 'stories'
    }


@app.route('/api/stories')
def api_stories():
    viewer = request.args.get('user_id')
    return jsonify({'rings': group_stories_by_user(viewer)})


@app.route('/api/story', methods=['POST'])
def api_create_story():
    """Créer une story (image base64, vidéo base64, ou texte)"""
    data = request.get_json(force=True, silent=True) or {}
    user_id = data.get('user_id') or str(uuid.uuid4())
    username = (data.get('username') or 'Anonyme')[:20]
    avatar_color = data.get('avatar_color') or '#B8860B'
    story_type = data.get('type', 'text')  # image | video | text
    caption = (data.get('caption') or '')[:200]
    text = (data.get('text') or '')[:500]

    story_id = str(uuid.uuid4())
    created = now_ts()
    expires = created + STORY_TTL_HOURS * 3600
    media_url = None
    media_path = None

    if story_type in ('image', 'video') and data.get('media_base64'):
        raw = data['media_base64']
        if ',' in raw:
            header, raw = raw.split(',', 1)
            ext = 'jpg'
            if 'png' in header:
                ext = 'png'
            elif 'webp' in header:
                ext = 'webp'
            elif 'mp4' in header or 'video' in header:
                ext = 'mp4'
        else:
            ext = 'jpg' if story_type == 'image' else 'mp4'

        try:
            binary = base64.b64decode(raw)
            if len(binary) > 10 * 1024 * 1024:
                return jsonify({'error': 'Fichier trop volumineux (max 10MB)'}), 400
            filename = f'{story_id}.{ext}'
            media_path = os.path.join(STORIES_DIR, filename)
            with open(media_path, 'wb') as f:
                f.write(binary)
            media_url = f'/static/stories/{filename}'
        except Exception as e:
            log.error('Media decode error: %s', e)
            return jsonify({'error': 'Media invalide'}), 400

    if story_type == 'text' and not text.strip():
        return jsonify({'error': 'Texte vide'}), 400
    if story_type in ('image', 'video') and not media_url:
        return jsonify({'error': 'Media manquant'}), 400

    story = {
        'id': story_id,
        'user_id': user_id,
        'username': username,
        'avatar_color': avatar_color,
        'type': story_type,
        'media_url': media_url,
        'media_path': media_path,
        'text': text if story_type == 'text' else None,
        'caption': caption,
        'created_at': created,
        'expires_at': expires,
        'views': set()
    }

    with stories_lock:
        stories.append(story)

    payload = public_story(story, user_id)
    socketio.emit('story_added', payload)
    log.info('Story créée %s par %s (%s)', story_id, username, story_type)
    return jsonify({'ok': True, 'story': payload})


@app.route('/api/story/<story_id>/view', methods=['POST'])
def api_view_story(story_id):
    data = request.get_json(force=True, silent=True) or {}
    viewer_id = data.get('user_id')
    with stories_lock:
        for s in stories:
            if s['id'] == story_id:
                if viewer_id:
                    s.setdefault('views', set()).add(viewer_id)
                return jsonify({'ok': True, 'views_count': len(s.get('views', set()))})
    return jsonify({'error': 'Story introuvable'}), 404


@app.route('/static/stories/<path:filename>')
def serve_story_media(filename):
    return send_from_directory(STORIES_DIR, filename)


# ============================================
# SOCKET.IO (présence légère)
# ============================================

@socketio.on('connect')
def on_connect():
    sid = request.sid
    users[sid] = {
        'user_id': None,
        'username': None,
        'connected_at': datetime.utcnow().isoformat()
    }
    emit('connected', {'sid': sid})


@socketio.on('disconnect')
def on_disconnect():
    users.pop(request.sid, None)


@socketio.on('register')
def on_register(data):
    sid = request.sid
    if sid not in users:
        return
    users[sid]['user_id'] = data.get('user_id')
    users[sid]['username'] = (data.get('username') or 'Anonyme')[:20]
    emit('registered', {
        'user_id': users[sid]['user_id'],
        'username': users[sid]['username']
    })


@socketio.on('get_rings')
def on_get_rings(data):
    viewer = (data or {}).get('user_id')
    emit('rings', {'rings': group_stories_by_user(viewer)})


if __name__ == '__main__':
    print('=' * 50)
    print('  Swip TV – Stories / Status')
    print('  Admin: oussamabbass500@gmail.com')
    print('  → http://0.0.0.0:5000')
    print('=' * 50)
    socketio.run(app, host='0.0.0.0', port=5000, debug=True, allow_unsafe_werkzeug=True)
